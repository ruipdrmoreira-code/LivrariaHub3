const puppeteer = require("puppeteer");
const mysql = require("mysql2/promise");

const DB_CONFIG = {
  host: process.env.DB_HOST || "127.0.0.1",
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || process.env.DB_USERNAME || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || process.env.DB_DATABASE || "livrariahub2",
};

/** Secções iniciais (1.º ao 12.º ano). Pré-escolar removido a pedido. */
const URLS_WOOK = [
  "https://www.wook.pt/livros-escolares",
  "https://www.wook.pt/arvoretematica/ensino-e-educacao/25188x25789x25945/P",
  "https://www.wook.pt/arvoretematica/1-ano/8070x5817x5822/P",
  "https://www.wook.pt/arvoretematica/2-ano/8070x5817x5830/P",
  "https://www.wook.pt/arvoretematica/3-ano/8070x5817x5838/P",
  "https://www.wook.pt/arvoretematica/4-ano/8070x5817x5382/P",
  "https://www.wook.pt/arvoretematica/5-ano/8070x5817x5393/P",
  "https://www.wook.pt/arvoretematica/6-ano/8070x5817x5404/P",
  "https://www.wook.pt/arvoretematica/7-ano/8070x5817x5415/P",
  "https://www.wook.pt/arvoretematica/8-ano/8070x5817x5429/P",
  "https://www.wook.pt/arvoretematica/9-ano/8070x5817x5444/P",
  "https://www.wook.pt/arvoretematica/10-ano/8070x5817x5459/P",
  "https://www.wook.pt/arvoretematica/11-ano/8070x5817x5470/P",
  "https://www.wook.pt/arvoretematica/12-ano/8070x5817x5481/P",
];
const SCRAPER_FAST = process.env.SCRAPER_FAST !== "false";
const ESPERA_ENTRE_PAGINAS_MS = Number(process.env.SCRAPER_LIST_WAIT_MS || (SCRAPER_FAST ? 1400 : 2500));
/** Máximo de páginas ?page=N por cada URL de listagem. */
const MAX_PAGINAS_POR_LISTAGEM = Math.min(
  Number(process.env.SCRAPER_MAX_PAGES || (SCRAPER_FAST ? 10 : 18)),
  25,
);
/** Em modo rápido não re-percorre sub-secções (URLs_WOOK já cobre anos). */
const SKIP_SECOES_EXTRA = process.env.SCRAPER_SKIP_SECOES !== "false" && SCRAPER_FAST;
/** Se "false", também grava anos fora de 1–12 (não recomendado). */
const APENAS_ANOS_1_A_12 = process.env.SCRAPER_ONLY_YEARS_1_12 !== "false";
const APAGAR_NAO_ESCOLARES = process.env.SCRAPER_DELETE_NON_SCHOOL === "true";
/** Visita a ficha de cada livro para obter editora e preço (recomendado). */
const BUSCAR_DETALHES_FICHA = process.env.SCRAPER_SKIP_DETAILS !== "true";
const ESPERA_ENTRE_DETALHES_MS = Number(process.env.SCRAPER_DETAIL_DELAY_MS || (SCRAPER_FAST ? 60 : 200));
/** Páginas Puppeteer em paralelo (12 ≈ ~10–15 min para ~2500 fichas). */
const SCRAPER_CONCURRENCY = Math.min(
  16,
  Math.max(1, Number(process.env.SCRAPER_CONCURRENCY || (SCRAPER_FAST ? 12 : 6))),
);
const DETALHE_TIMEOUT_MS = Number(process.env.SCRAPER_DETAIL_TIMEOUT_MS || 28000);
const DETALHE_ESPERA_MS = Number(process.env.SCRAPER_DETAIL_WAIT_MS || (SCRAPER_FAST ? 220 : 500));
/** 0 = todos os livros filtrados; útil para testes (ex.: 50). */
const MAX_DETALHES_POR_CORRIDA = Number(process.env.SCRAPER_MAX_DETAILS || 0);
/** Se "true", só abre ficha quando falta preço ou editora. */
const SO_DETALHES_EM_FALTA = process.env.SCRAPER_ONLY_MISSING_DETAILS !== "false";
const GRAVAR_INCREMENTAL = process.env.SCRAPER_NO_INCREMENTAL !== "true";
const SCRAPER_MODE = String(process.env.SCRAPER_MODE || "full").toLowerCase();
/** Ativado quando a tabela livros está vazia: listagens curtas + fichas só em falta (~10–15 min). */
let PERFIL_BD_VAZIA = false;

function getMaxPaginasListagem() {
  if (process.env.SCRAPER_MAX_PAGES) return Math.min(Number(process.env.SCRAPER_MAX_PAGES), 25);
  if (PERFIL_BD_VAZIA) return 4;
  return SCRAPER_FAST ? 10 : 18;
}

function getConcurrency() {
  if (process.env.SCRAPER_CONCURRENCY) {
    return Math.min(16, Math.max(1, Number(process.env.SCRAPER_CONCURRENCY)));
  }
  if (PERFIL_BD_VAZIA) return 14;
  return SCRAPER_FAST ? 12 : 6;
}

function getEsperaDetalhesMs() {
  if (process.env.SCRAPER_DETAIL_DELAY_MS) return Number(process.env.SCRAPER_DETAIL_DELAY_MS);
  if (PERFIL_BD_VAZIA) return 40;
  return SCRAPER_FAST ? 60 : 200;
}

function getDetalheEsperaMs() {
  if (process.env.SCRAPER_DETAIL_WAIT_MS) return Number(process.env.SCRAPER_DETAIL_WAIT_MS);
  if (PERFIL_BD_VAZIA) return 180;
  return SCRAPER_FAST ? 220 : 500;
}
const EDU_KEYWORDS = [
  "manual",
  "escolar",
  "educacao",
  "educação",
  "caderno de atividades",
  "caderno atividades",
  "fichas",
  "exames",
  "escola",
  "ensino",
  "professor",
  "aluno",
  "didatico",
  "didático",
  "preparacao",
  "preparação",
  "portugues",
  "português",
  "matematica",
  "matemática",
  "ciencias",
  "ciências",
  "historia",
  "história",
  "geografia",
  "fisico-quimica",
  "físico-química",
  "secundario",
  "secundário",
  "1º ano",
  "2º ano",
  "3º ano",
  "4º ano",
  "5º ano",
  "6º ano",
  "7º ano",
  "8º ano",
  "9º ano",
  "10º ano",
  "11º ano",
  "12º ano",
];
const NON_SCHOOL_KEYWORDS = [
  "romance",
  "novela",
  "ficcao",
  "ficção",
  "literatura",
  "poesia",
  "conto",
];

function normalizarUrl(url) {
  if (!url) return "https://www.wook.pt/";
  if (url.startsWith("http")) return url;
  return `https://www.wook.pt${url}`;
}

/** Título legível a partir do último segmento do URL Wook (/livro/...-slug). */
function tituloDeSlugUrlWook(url) {
  const u = String(url || "").trim();
  if (!u) return "";
  let pathname = "";
  try {
    pathname = new URL(u.startsWith("http") ? u : `https://www.wook.pt${u}`).pathname;
  } catch {
    return "";
  }
  const seg = pathname.split("/").filter(Boolean).pop() || "";
  if (!seg || seg.length < 6 || /^\d+$/.test(seg)) return "";
  let decoded = seg;
  try {
    decoded = decodeURIComponent(seg);
  } catch {
    decoded = seg;
  }
  let t = decoded.replace(/[-_]+/g, " ").replace(/\s+/g, " ").trim();
  t = t.replace(/\s*x\s*\d+$/i, "").replace(/\s+P\d+$/i, "").trim();
  if (t.length < 5) return "";
  return limparTexto(
    t
      .split(/\s+/)
      .map((w) => (w.length ? w.charAt(0).toUpperCase() + w.slice(1).toLowerCase() : ""))
      .filter(Boolean)
      .join(" "),
  );
}

/** Ano escolar 1–12 a partir do URL Wook (ex.: /5-ano/...). */
function derivarAnoDaUrlWook(url) {
  const m = String(url || "").match(/\/(\d{1,2})-ano\b/i);
  if (!m) return 0;
  const n = Number(m[1]);
  return n >= 1 && n <= 12 ? n : 0;
}

function urlComPagina(base, num) {
  if (num <= 1) return base;
  try {
    const u = new URL(base);
    u.searchParams.set("page", String(num));
    return u.href;
  } catch (_e) {
    return `${base}${base.includes("?") ? "&" : "?"}page=${num}`;
  }
}

/** Editoras frequentes no título (fallback quando a página não traz brand). */
const EDITORAS_NO_TITULO = [
  { re: /\bPorto\s+Editora\b/i, nome: "Porto Editora" },
  { re: /\bAreal\s+Editores\b/i, nome: "Areal Editores" },
  { re: /\bTexto\s+Editores\b/i, nome: "Texto Editores" },
  { re: /\bLeya\b/i, nome: "Leya" },
  { re: /\bASA\b(?!\w)/i, nome: "ASA Editores" },
  { re: /\bGradiva\b/i, nome: "Gradiva" },
  { re: /\bCambridge\b/i, nome: "Cambridge University Press" },
  { re: /\bOxford\b/i, nome: "Oxford University Press" },
  { re: /\bRaiz\s+Editores\b/i, nome: "Raiz Editores" },
  { re: /\bPlátano\b|\bPlatano\b/i, nome: "Plátano Editora" },
  { re: /\bGailivro\b/i, nome: "Gailivro" },
  { re: /\bHachette\b/i, nome: "Hachette" },
  { re: /\bMcGraw[-\s]?Hill\b/i, nome: "McGraw-Hill" },
  { re: /\bSantillana\b/i, nome: "Santillana" },
  { re: /\bZigzag\b/i, nome: "Zigzag" },
  { re: /\bEu\s+Leio\b/i, nome: "Eu Leio" },
  { re: /\bEdi[cç][oõ]es\s+Asa\b|\bEdi[cç]oes\s+Asa\b/i, nome: "Edições Asa" },
  { re: /\bSebenta\b/i, nome: "Sebenta" },
  { re: /\bNova\s+Gaia\b/i, nome: "Edições Nova Gaia" },
  { re: /\bLivro\s+Directo\b|\bLivro\s+Direto\b/i, nome: "Edições Livro Directo" },
  { re: /\bDid[aá]ctica\b/i, nome: "Didática" },
  { re: /\bLidel\b/i, nome: "Lidel" },
  { re: /\bBru[aã]\b/i, nome: "Bruã" },
  { re: /\bEuroimpala\b/i, nome: "Euroimpala" },
  { re: /\bManuscrito\b/i, nome: "Manuscrito" },
  { re: /\bIdeia\s+Editorial\b/i, nome: "Ideia Editorial" },
  { re: /\bVera\s+Veras\b/i, nome: "Vera Veras" },
  { re: /\bEdelvives\b/i, nome: "Edelvives" },
  { re: /\bBooksmile\b/i, nome: "Booksmile" },
  { re: /\bIdeias\s+de\s+Ler\b/i, nome: "Ideias de Ler" },
  { re: /\bNovatec\b/i, nome: "Novatec" },
  { re: /\bELFI\b/i, nome: "ELFI" },
  { re: /\bPanda\b(?!\s+TV)/i, nome: "Panda" },
  { re: /\bPresen[cç]a\b/i, nome: "Presença" },
  { re: /\bCiviliza[cç][aã]o\s+Editora\b/i, nome: "Civilização Editora" },
  { re: /\bLeya\s+Educa[cç][aã]o\b/i, nome: "Leya Educação" },
  { re: /\bOrion\b/i, nome: "Orion" },
];

function inferirEditoraDoTitulo(titulo) {
  const t = String(titulo || "");
  for (const { re, nome } of EDITORAS_NO_TITULO) {
    if (re.test(t)) return nome;
  }
  return "";
}

function resolverAnoEscolarFinal(livro) {
  const textoTituloCtx = `${livro?.titulo || ""} ${livro?.contextoSecao || ""}`;
  const doTituloOuCtx = mapearAnoEscolar(textoTituloCtx);
  if (doTituloOuCtx >= 1 && doTituloOuCtx <= 12) return doTituloOuCtx;

  const aDet = Number(livro?.anoEscolar || 0);
  if (aDet >= 1 && aDet <= 12) return aDet;

  const uLink = derivarAnoDaUrlWook(livro?.link);
  if (uLink >= 1 && uLink <= 12) return uLink;

  const uLista = derivarAnoDaUrlWook(livro?.urlListagem);
  if (uLista >= 1 && uLista <= 12) return uLista;

  return aDet || 0;
}

function resolverEditoraFinal(livro) {
  let raw = sanearNomeEditora(livro?.editora || "").replace(/^[/|\\\s—–-]+/, "").trim();
  if (raw && raw.toLowerCase() !== "desconhecida") return raw.slice(0, 255);
  const doTitulo = inferirEditoraDoTitulo(livro?.titulo);
  if (doTitulo) return doTitulo.slice(0, 255);
  const doSlug = editoraDoSlugUrlWook(livro?.link);
  if (doSlug) return doSlug.slice(0, 255);
  return "Desconhecida";
}

/** Nome da editora a partir do URL /editora/slug (fallback). */
function editoraDoSlugUrlWook(url) {
  const m = String(url || "").match(/\/editora\/([^/?#]+)/i);
  if (!m || !m[1]) return "";
  let slug = m[1];
  try {
    slug = decodeURIComponent(slug);
  } catch {
    /* ignore */
  }
  if (/^\d+$/i.test(slug)) return "";
  const nome = limparTexto(slug.replace(/[-_]+/g, " "));
  if (nome.length < 3 || nome.length > 80) return "";
  return nome
    .split(/\s+/)
    .map((w) => (w.length ? w.charAt(0).toUpperCase() + w.slice(1).toLowerCase() : ""))
    .filter(Boolean)
    .join(" ")
    .slice(0, 255);
}

function livroAnoPermitido(livro) {
  if (!APENAS_ANOS_1_A_12) return true;
  const a = resolverAnoEscolarFinal(livro);
  return a >= 1 && a <= 12;
}

function limparTexto(valor) {
  return (valor || "").replace(/\s+/g, " ").trim();
}

/** Normaliza separadores “tipo ponto médio” da Wook para um único carácter cortável. */
function normalizarSeparadoresFicha(s) {
  return String(s || "")
    .replace(/\u00A0/g, " ")
    .replace(/[\u00B7\u2022\u2027\u2219\u22C5\u30FB‧⋅·]/g, "·");
}

/** Corta texto típico da ficha Wook (UI, stock, avaliações) que cai no campo editora. */
function cortarLixoUiEditora(s) {
  let t = normalizarSeparadoresFicha(limparTexto(String(s || "")));
  if (!t) return "";
  // Na Wook o separador costuma ser hífen antes de "ver detalhes", não só o ponto médio (·).
  t = t.replace(/\s*-\s*ver\s+detalhes\b.*/i, "").trim();
  t = t.replace(/\s+e\s+ver\s+detalhes\b.*/i, "").trim();
  t = t.replace(/\s*·\s*.*$/s, "").trim();
  t = t.replace(/\s*\|\s*.*$/s, "").trim();
  t = t.replace(/\s+i\s+\d{1,3}[.,]\d{2}\s*€.*$/i, "").trim();
  t = t.replace(/\s+\d{1,3}[.,]\d{2}\s*€.*$/i, "").trim();
  t = t.replace(/\s+\d{1,3}[.,]\d{2}\s*€\s+i\s+.*$/i, "").trim();
  t = t.replace(/\s+\d{1,2}\s*%\s*DESCONTO.*$/i, "").trim();
  t = t.replace(/\bDESCONTO\b.*$/i, "").trim();
  t = t.replace(/\bseja\s+o\s+primeiro\s+a\s+comentar\b.*$/i, "").trim();
  t = t.replace(/\bE(\s+E){2,}\b.*$/i, "").trim();
  const cortes = [
    /\s+ver\s+detalhes\b.*/i,
    /\s+detalhes\s+do\s+produto\b.*/i,
    /\s+avalia[cç][aã]o\s+dos\s+leitores\b.*/i,
    /\s+avalia[cç][oõ]es?\s+dos\s+leitores\b.*/i,
    /\s*\(?\s*\d+\s+coment[aá]rios?\s*\)?/gi,
    /\(\s*\d+\s*\)\s*/g,
    /\besgotado\b.*$/i,
    /\bn[aã]o\s+dispon[ií]vel\b.*$/i,
    /\s+e\s+e\s+e\s+e\s+e\s+/gi,
  ];
  for (let pass = 0; pass < 4; pass++) {
    for (const rx of cortes) {
      t = t.replace(rx, " ").trim();
    }
  }
  t = t.replace(
    /\s*,\s*(janeiro|fevereiro|mar[cç]o|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro)\s+de\s+\d{4}.*$/i,
    "",
  ).trim();
  t = t.replace(/\s{2,}/g, " ").trim();
  t = t.replace(/^[/|\\\s—–-]+/, "").trim();
  return t;
}

/** Remove vírgulas iniciais e trechos que são só data ("novembro de 2009"), para não gravar lixo na editora. */
function segmentoEhSohMetadado(seg) {
  const t = cortarLixoUiEditora(String(seg || ""));
  if (t.length < 4) return true;
  return /^(janeiro|fevereiro|mar[cç]o|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro)\s+de\s+\d{4}$/i.test(t);
}

const MESES_PT = "janeiro|fevereiro|mar[cç]o|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro";

function sanearNomeEditora(texto) {
  let s = cortarLixoUiEditora(String(texto || ""))
    .replace(/^[,;\s]+/, "")
    .replace(/\s{2,}/g, " ");
  if (!s || s.toLowerCase() === "desconhecida") return "";
  if (segmentoEhSohMetadado(s)) return "";
  const rxDataAposVirgula = new RegExp(`\\s*,\\s*(${MESES_PT})\\s+de\\s+\\d{4}.*$`, "i");
  const partes = s
    .split(",")
    .map((p) => cortarLixoUiEditora(p.trim()).replace(rxDataAposVirgula, "").trim())
    .filter(Boolean);
  for (const p of partes) {
    if (segmentoEhSohMetadado(p)) continue;
    let cand = limparTexto(p);
    if (cand.length < 3) continue;
    if (cand.length > 120) {
      cand = cortarLixoUiEditora(cand);
      if (cand.length > 120) cand = cand.slice(0, 120).replace(/\s+\S*$/, "").trim();
    }
    if (cand.length >= 3) return cand;
  }
  let mono = cortarLixoUiEditora(s).replace(rxDataAposVirgula, "").trim();
  mono = mono.replace(new RegExp(`^(${MESES_PT})\\s+de\\s+\\d{4}.*$`, "i"), "").trim();
  if (segmentoEhSohMetadado(mono) || mono.length < 3) return "";
  if (mono.length > 120) mono = mono.slice(0, 120).replace(/\s+\S*$/, "").trim();
  return mono.length >= 3 ? mono : "";
}

function tituloAceitavel(t) {
  const s = limparTexto(String(t || ""));
  if (s.length < 4) return false;
  if (/^\d{1,2}\s*%\s*$/i.test(s)) return false;
  if (/^\d+[.,]\d{2}\s*€\s*$/i.test(s)) return false;
  if (s.length <= 14 && /^[\d.,\s€%|]+$/i.test(s)) return false;
  if (s.length <= 10 && /\d{1,2}\s*%/.test(s) && !/\b(ano|º|volume|livro|caderno|manual|portugu|matem|hist|ingl|exame|fich|prep)\b/i.test(s)) {
    return false;
  }
  return true;
}

/** Primeira frase da meta description (fallback de título na ficha Wook). */
function primeiroTrechoMetaDescricao(texto) {
  const s = limparTexto(String(texto || ""));
  if (s.length < 12 || s.length > 500) return "";
  const trecho = limparTexto((s.split(/[.·\n]/)[0] || "").trim());
  if (trecho.length < 12 || /^[\d.,\s€%]+$/i.test(trecho)) return "";
  return trecho;
}

/** Prefere o primeiro título que não seja só desconto / ruído (ex.: "10%"). */
function escolherTituloFinal(...candidatos) {
  for (const c of candidatos) {
    const t = limparTitulo(limparTexto(c || ""));
    if (tituloAceitavel(t)) return t;
  }
  const fallback = limparTitulo(limparTexto(candidatos.find(Boolean) || ""));
  return fallback || "";
}

function limparTitulo(titulo) {
  let t = limparTexto(String(titulo || ""));
  // Só remover percentagens / promo no **fim** do título (evita apagar tudo se houver "10%" a meio)
  for (let i = 0; i < 4; i++) {
    const antes = t;
    t = t.replace(/\s*[-–—]\s*\d{1,2}\s*%\s*(DE\s+DESC\w*)?\s*$/i, "").trim();
    t = t.replace(/\s+\d{1,2}\s*%\s*(DE\s+DESC\w*)?\s*$/i, "").trim();
    t = t.replace(/\s*\(\s*\d{1,2}\s*%\s*\)\s*$/i, "").trim();
    if (t === antes) break;
  }
  t = t.replace(/\s*\|\s*\d+[.,]\d{2}\s*€.*$/i, "").trim();
  t = t.replace(/\s{2,}/g, " ").trim();
  if (/^\d{1,2}\s*%$/i.test(t)) return "";
  return t;
}

function parsePreco(valor) {
  if (!valor) return 0;
  const texto = String(valor).replace(/[^\d,.]/g, "").replace(",", ".");
  const numero = Number.parseFloat(texto);
  return Number.isFinite(numero) ? Number(numero.toFixed(2)) : 0;
}

/** ISBN no final do URL Wook (ex.: ..._97902358860790). */
function isbnDoLinkWook(url) {
  const m = String(url || "").match(/[_-](97[89]\d{10})(?:[/?#]|$)/i);
  return m ? m[1] : "";
}

/** URL da ficha Wook a partir do título + ISBN (funciona mesmo sem slug exacto). */
function construirLinkWook(livro) {
  if (livro?.link && /\/livro\//i.test(livro.link)) return normalizarUrl(livro.link);
  const isbn = String(livro?.isbn || isbnDoLinkWook(livro?.link) || "").replace(/\D/g, "");
  if (isbn.length < 13) return "";
  let slug = limparTitulo(livro?.titulo || "livro")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 90);
  if (!slug || slug.length < 3) slug = "livro";
  return `https://www.wook.pt/livro/${slug}_${isbn.slice(0, 13)}`;
}

async function configurarPaginaListagem(page) {
  await page.setUserAgent(
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
  );
  await page.setCacheEnabled(true);
}

async function configurarPaginaRapida(page) {
  await page.setUserAgent(
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
  );
  await page.setCacheEnabled(true);
  await page.setRequestInterception(true);
  page.on("request", (req) => {
    const type = req.resourceType();
    const u = req.url();
    if (
      ["image", "stylesheet", "font", "media"].includes(type) ||
      /google-analytics|googletagmanager|doubleclick|hotjar|facebook\.net|clarity\.ms/i.test(u)
    ) {
      req.abort();
      return;
    }
    req.continue();
  });
}

/** Uma única navegação por livro (evita goto duplo). Devolve false se não abriu ficha. */
async function abrirFichaLivro(page, livro) {
  const candidatos = [construirLinkWook(livro), livro?.link].filter(Boolean);
  for (const url of candidatos) {
    try {
      const resp = await page.goto(url, {
        waitUntil: SCRAPER_FAST ? "domcontentloaded" : "domcontentloaded",
        timeout: DETALHE_TIMEOUT_MS,
      });
      if (resp && resp.status() >= 400) continue;
      if (/\/livro\//i.test(page.url())) {
        return normalizarUrl(page.url());
      }
    } catch (_e) {
      /* tenta seguinte */
    }
  }
  const isbn = String(livro?.isbn || "").replace(/\D/g, "");
  if (isbn.length >= 10) {
    try {
      await page.goto(`https://www.wook.pt/pesquisa?query=${encodeURIComponent(isbn)}`, {
        waitUntil: "domcontentloaded",
        timeout: DETALHE_TIMEOUT_MS,
      });
      await esperar(SCRAPER_FAST ? 280 : 500);
      const href = await page.evaluate(() => {
        const a = document.querySelector('a[href*="/livro/"]');
        return a ? a.getAttribute("href") || "" : "";
      });
      if (href) {
        await page.goto(normalizarUrl(href), {
          waitUntil: "domcontentloaded",
          timeout: DETALHE_TIMEOUT_MS,
        });
        if (/\/livro\//i.test(page.url())) return normalizarUrl(page.url());
      }
    } catch (_e) {
      /* ignore */
    }
  }
  return "";
}

async function processarFichaLivro(page, livro) {
  const url = await abrirFichaLivro(page, livro);
  if (!url) return null;
  livro.link = url;
  return extrairDetalhesLivro(page, { skipGoto: true });
}

function precisaDetalheFicha(livro) {
  const preco = Number(livro?.preco || 0);
  const ed = String(livro?.editora || "")
    .trim()
    .toLowerCase();
  if (preco <= 0) return true;
  if (!ed || ed === "desconhecida" || ed === "não indicada" || ed === "nao indicada") return true;
  return false;
}

function mergeDetalheNoLivro(livro, det) {
  if (!livro || !det) return;
  const tituloNovo = escolherTituloFinal(det.titulo, livro.titulo);
  if (tituloNovo) livro.titulo = tituloNovo;
  const isbnDet = limparTexto(det.isbn);
  if (isbnDet) livro.isbn = isbnDet;
  else if (!livro.isbn) livro.isbn = isbnDoLinkWook(livro.link);
  if (det.preco > 0) livro.preco = det.preco;
  const edDet = sanearNomeEditora(det.editora);
  if (edDet && edDet.toLowerCase() !== "desconhecida") {
    livro.editora = edDet;
  } else {
    livro.editora = resolverEditoraFinal(livro);
  }
  const meta = textoMetaLivro(livro, det);
  livro.tipo = mapearTipo(meta);
  livro.disciplina = mapearDisciplina(meta);
  if (Number(det.anoEscolar) >= 1 && Number(det.anoEscolar) <= 12) {
    livro.anoEscolar = Number(det.anoEscolar);
  }
}

async function enriquecerLivrosComDetalhes(browser, livros, onLoteGravado, opts = {}) {
  if (!BUSCAR_DETALHES_FICHA || !livros?.length) return livros;

  const candidatos = MAX_DETALHES_POR_CORRIDA > 0 ? livros.slice(0, MAX_DETALHES_POR_CORRIDA) : livros;
  const paraVisitar = opts.forceAll
    ? candidatos
    : SO_DETALHES_EM_FALTA
      ? candidatos.filter(precisaDetalheFicha)
      : candidatos;
  const total = paraVisitar.length;

  if (total === 0) {
    console.log("Nenhuma ficha de produto pendente (editora/preco ja preenchidos).");
    return livros;
  }

  const inicio = Date.now();
  const conc = getConcurrency();
  const esperaMs = getEsperaDetalhesMs();
  console.log(`Fichas Wook: ${total} livros | ${conc} em paralelo | espera ${esperaMs}ms`);

  let cursor = 0;
  let ok = 0;
  let falhas = 0;
  const bufferGravar = [];
  let gravando = Promise.resolve();

  const enfileirarGravar = (lote) => {
    if (!onLoteGravado || !lote.length) return;
    gravando = gravando.then(() => onLoteGravado(lote));
  };

  async function worker() {
    const page = await browser.newPage();
    await configurarPaginaRapida(page);
    try {
      while (true) {
        const i = cursor++;
        if (i >= total) break;

        const livro = paraVisitar[i];
        try {
          if (i % 100 === 0 || i === total - 1) {
            const elapsed = ((Date.now() - inicio) / 1000).toFixed(0);
            const rate = i > 0 ? (i / ((Date.now() - inicio) / 1000)).toFixed(1) : "0";
            console.log(`  ${i + 1}/${total} (${elapsed}s, ~${rate}/s) ${(livro.titulo || "").slice(0, 45)}`);
          }
          const det = await processarFichaLivro(page, livro);
          if (!det) {
            falhas += 1;
            continue;
          }
          mergeDetalheNoLivro(livro, det);
          ok += 1;

          if (GRAVAR_INCREMENTAL && onLoteGravado) {
            bufferGravar.push(livro);
            if (bufferGravar.length >= 40) {
              const lote = bufferGravar.splice(0, bufferGravar.length);
              enfileirarGravar(lote);
            }
          }
        } catch (e) {
          falhas += 1;
          if (falhas <= 8) console.warn(`  Falha: ${(livro.titulo || "").slice(0, 40)} — ${e.message}`);
        }
        const espera = getEsperaDetalhesMs();
        if (espera > 0) await esperar(espera);
      }
    } finally {
      await page.close().catch(() => {});
    }
  }

  await Promise.all(Array.from({ length: getConcurrency() }, () => worker()));

  if (bufferGravar.length) enfileirarGravar(bufferGravar.splice(0, bufferGravar.length));
  await gravando;

  const mins = ((Date.now() - inicio) / 60000).toFixed(1);

  console.log(`Fichas Wook: ${ok} ok, ${falhas} falhas, ${mins} min.`);
  return livros;
}

function gerarIsbnFallback(link, titulo) {
  const base = `${link}|${titulo}`;
  let hash = 0;
  for (let i = 0; i < base.length; i += 1) {
    hash = (hash * 31 + base.charCodeAt(i)) >>> 0;
  }
  const hashTexto = String(hash).padStart(10, "0").slice(0, 10);
  return `9790${hashTexto}`;
}

function normalizarTextoMeta(s) {
  return String(s || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

/** Manual por defeito em material escolar; caderno só com indícios claros no título/ficha. */
function mapearTipo(textoBase) {
  const texto = normalizarTextoMeta(textoBase);
  if (/\bmanual\s+escolar\b|\bmanual\s+de\b|\bmanual\s+do\b|\bmanual\s+do\s+aluno\b/.test(texto)) {
    return "MANUAL";
  }
  if (
    /\bcaderno\s+de\s+atividades\b/.test(texto) ||
    /\bcaderno\s+de\s+apoio\b/.test(texto) ||
    /\bfichas?\s+de\b/.test(texto) ||
    /\bfichas?\s+de\s+trabalho\b/.test(texto) ||
    /\bprovas?\s+de\s+exame\b/.test(texto) ||
    /\bpreparar\s+(os\s+)?testes\b/.test(texto) ||
    /\btestes\s+e\s+exames?\b/.test(texto) ||
    /\bguia\s+de\s+estudo\b/.test(texto) ||
    /\bresumos?\s*[-–]/.test(texto) ||
    /\bapontamentos\b/.test(texto) ||
    /\bhiper\s+apontamentos\b/.test(texto) ||
    /\bexerc[ií]cios?\s+de\b/.test(texto) ||
    /\bcaderno\b/.test(texto) && /\batividades\b/.test(texto)
  ) {
    return "CADERNO_ATIVIDADES";
  }
  if (/\bmanual\b/.test(texto)) return "MANUAL";
  if (/\binfantil\b/.test(texto) || /\bpre-escolar\b/.test(texto)) return "INFANTIL";
  if (/\bpython\b/.test(texto) || /\bsql\b/.test(texto) || /\btecnico\b/.test(texto)) return "TECNICO";
  return "MANUAL";
}

function mapearDisciplina(textoBase) {
  const texto = normalizarTextoMeta(textoBase);
  if (/\bestudo do meio\b/.test(texto)) return "Estudo do Meio";
  if (/\bhistoria e geografia\b|\bhgp\b/.test(texto)) return "Historia e Geografia de Portugal";
  if (/\beducacao visual\b|\bed\.?\s*visual\b/.test(texto)) return "Educacao Visual";
  if (/\beducacao tecnologica\b|\bed\.?\s*tecnolog/.test(texto)) return "Educacao Tecnologica";
  if (/\beducacao musical\b/.test(texto)) return "Educacao Musical";
  if (/\beducacao fisica\b|\bed\.?\s*fisica\b/.test(texto)) return "Educacao Fisica";
  if (/\beconomia\b/.test(texto)) return "Economia";
  if (/\bfilosofia\b/.test(texto)) return "Filosofia";
  if (/\blingua portuguesa\b|\bportugues\b/.test(texto) && !/\bportugal\b/.test(texto)) return "Portugues";
  if (/\bmatematica\b|\bmacs\b|\bmatemat\b/.test(texto)) return "Matematica";
  if (/\bingles\b/.test(texto)) return "Ingles";
  if (/\bfrances\b/.test(texto)) return "Frances";
  if (/\bespanhol\b/.test(texto)) return "Espanhol";
  if (/\bportugu\b/.test(texto) && !/\bportugal\b/.test(texto)) return "Portugues";
  if (/\bgeografia\b|\bgeograf/.test(texto)) return "Geografia";
  if (/\bfisico-quimica\b|\bfisico quimica\b|\bfisica e quimica\b/.test(texto)) return "Fisico-Quimica";
  if (/\bfisic\b/.test(texto) || /\bquim\b/.test(texto) || /\bfq\b/.test(texto)) return "Fisico-Quimica";
  if (/\bbiolog/.test(texto)) return "Biologia";
  if (/\bhist\b/.test(texto)) return "Historia";
  if (/\bciencias naturais\b|\bciencias\b|\bc\.?\s*n\.?\b/.test(texto)) return "Ciencias";
  if (/\bled\.?\s*econ\b/.test(texto)) return "Economia";
  return "Educacao";
}

function textoMetaLivro(livro, det = {}) {
  return [
    det.titulo,
    det.classificacaoTematica,
    det.textoRelevante,
    Array.isArray(det.breadcrumb) ? det.breadcrumb.join(" ") : "",
    det.descricaoCurta,
    det.tipoWook,
    livro?.titulo,
    livro?.contextoSecao,
    livro?.urlListagem,
  ]
    .filter(Boolean)
    .join(" ");
}

function mapearAnoEscolar(textoBase) {
  const texto = (textoBase || "").toLowerCase();
  const patterns = [
    /\b(\d{1,2})\s*[.º°]{1,2}\s*ano\b/i,
    /\b(\d{1,2})\s*\.\s*º\s*ano\b/i,
    /(?:^|[^\d])(1[0-2]|[1-9])(?:\s*[\.\-º°o]\s*|\s*)ano\b/i,
    /\b(1[0-2]|[1-9])-(?:ano)\b/i,
    /\bano\b\s*(1[0-2]|[1-9])/i,
  ];
  for (const re of patterns) {
    const m = texto.match(re);
    if (m) {
      const n = Number(m[1]);
      if (n >= 1 && n <= 12) return n;
    }
  }
  if (texto.includes("pré-escolar") || texto.includes("pre-escolar") || texto.includes("pre escolar")) return -1;
  return 0;
}

function extrairContextoRelevante(texto) {
  const base = String(texto || "");
  const linhas = base
    .split(/\r?\n/)
    .map((l) => limparTexto(l))
    .filter(Boolean);
  const relevantes = linhas.filter((linha) =>
    /classificação temática|classificacao tematica|livros escolares|apoio escolar|pré-escolar|pre-escolar|ensino básico|ensino basico|secundário|secundario|\b[1-9]\s*[.º°o]?\s*ano\b|\b1[0-2]\s*[.º°o]?\s*ano\b|matem|portugu|hist|geograf|fisic|quim|biolog|franc|ingl|espanhol|filosof|ciencias|hgp|estudo do meio|educação visual|educacao visual|educação tecnológica|educacao tecnologica/i.test(
      linha,
    ),
  );
  return relevantes.join(" | ");
}

function temDadosMinimos(livro) {
  if (!livro?.titulo || !livro?.link) return false;
  // Livros escolares muitas vezes não têm ISBN na listagem, e podem estar sem preço (esgotados).
  // Como já filtramos estritamente antes, podemos ser menos exigentes aqui.
  return true;
}

function esperar(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function ehLivroEscolar(livro) {
  const link = `${livro?.link || ""} ${livro?.urlListagem || ""}`.toLowerCase();
  if (/livros-escolares|apoio-escolar|arvoretematica|\/\d{1,2}-ano\b|ensino-e-educacao/i.test(link)) {
    return true;
  }
  const texto = `${livro?.titulo || ""} ${livro?.link || ""} ${livro?.editora || ""} ${livro?.contextoSecao || ""}`.toLowerCase();
  return EDU_KEYWORDS.some((keyword) => texto.includes(keyword));
}

function ehLivroEscolarEstrito(livro) {
  const texto = `${livro?.titulo || ""} ${livro?.link || ""} ${livro?.editora || ""} ${livro?.disciplina || ""} ${livro?.contextoSecao || ""}`.toLowerCase();
  const temIndicadorNaoEscolar = NON_SCHOOL_KEYWORDS.some((keyword) => texto.includes(keyword));
  const temIndicadorEscolar = EDU_KEYWORDS.some((keyword) => texto.includes(keyword));
  const anoEscolar = Number(livro?.anoEscolar || 0);
  const tipo = String(livro?.tipo || "").toUpperCase();
  const tipoEscolar = ["MANUAL", "CADERNO_ATIVIDADES"].includes(tipo);

  if (!temIndicadorEscolar && anoEscolar <= 0 && !tipoEscolar) return false;
  if (temIndicadorNaoEscolar && anoEscolar <= 0 && !tipoEscolar) return false;
  return true;
}

async function aceitarCookies(page) {
  const botoes = [
    "#onetrust-accept-btn-handler",
    "button[aria-label*='Aceitar']",
    "button[id*='accept']",
  ];
  for (const selector of botoes) {
    const botao = await page.$(selector);
    if (botao) {
      await botao.click();
      return;
    }
  }
}

/** Scroll para carregar listagens com lazy-load. */
async function scrollPagina(page) {
  try {
    await page.evaluate(async () => {
      const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
      const max = Math.min(document.scrollingElement?.scrollHeight || 8000, 20000);
      for (let y = 0; y < max; y += 700) {
        window.scrollTo(0, y);
        await sleep(120);
      }
      window.scrollTo(0, 0);
    });
  } catch (_e) {
    /* ignora */
  }
}

async function extrairLivrosDaPagina(page, urlListagem = "") {
  const dados = await page.evaluate(() => {
    const limpar = (v) => (v || "").replace(/\s+/g, " ").trim();
    const resultados = [];
    const vistos = new Set();
    const paraArray = (v) => (Array.isArray(v) ? v : [v]);

    const textoOrganizacao = (x) => {
      if (!x) return "";
      if (typeof x === "string") return x.trim();
      if (typeof x === "object") {
        if (x.name) return String(x.name).trim();
        if (x.legalName) return String(x.legalName).trim();
        if (Array.isArray(x)) return x.map(textoOrganizacao).filter(Boolean).join(" | ");
      }
      return "";
    };

    const guardar = (livro) => {
      if (!livro?.titulo || !livro?.link) return;
      const chave = `${livro.titulo}|${livro.link}`;
      if (vistos.has(chave)) return;
      vistos.add(chave);
      resultados.push(livro);
    };

    const scripts = Array.from(document.querySelectorAll("script[type='application/ld+json']"));
    for (const script of scripts) {
      try {
        const data = JSON.parse(script.textContent || "[]");
        const stack = paraArray(data);
        while (stack.length) {
          const item = stack.pop();
          if (!item || typeof item !== "object") continue;
          if (Array.isArray(item)) {
            stack.push(...item);
            continue;
          }
          if (item["@graph"]) stack.push(...paraArray(item["@graph"]));
          if (item.itemListElement) stack.push(...paraArray(item.itemListElement));
          if (item.mainEntity) stack.push(...paraArray(item.mainEntity));
          if (item.item) stack.push(...paraArray(item.item));

          const tipo = item["@type"];
          const isProduct =
            tipo === "Product" ||
            (Array.isArray(tipo) && tipo.includes("Product")) ||
            (item.name && (item.offers || item.url));
          if (!isProduct) continue;

          const offer = Array.isArray(item.offers) ? item.offers[0] : item.offers;
          const ed =
            textoOrganizacao(item.brand) ||
            textoOrganizacao(item.publisher) ||
            textoOrganizacao(item.manufacturer) ||
            textoOrganizacao(item.producer);
          guardar({
            titulo: item.name || "",
            preco: offer?.price || offer?.lowPrice || "",
            moeda: offer?.priceCurrency || "EUR",
            link: item.url || offer?.url || "",
            editora: ed,
            isbn: item.isbn || "",
          });
        }
      } catch (_e) {
        // ignora json inválido
      }
    }

    const links = Array.from(document.querySelectorAll("a[href]")).filter((a) =>
      /\/livro\//i.test(a.getAttribute("href") || ""),
    );
    for (const link of links) {
      const wrap =
        link.closest("article, li, [class*='product'], [class*='card'], [data-product], div") || link.parentElement;
      const heading = wrap?.querySelector("h2, h3, [class*='product-title'], [class*='titulo']");
      const titulo = limpar(
        link.getAttribute("title") ||
          heading?.textContent ||
          link.getAttribute("aria-label") ||
          link.textContent ||
          "",
      );
      if (titulo.length < 2) continue;
      const href = link.getAttribute("href") || "";
      const texto = wrap?.innerText || "";
      let preco = "";
      const precoEl = wrap?.querySelector(
        '[itemprop="price"], [class*="price" i], [class*="preco" i], [data-price]',
      );
      if (precoEl) {
        const raw = precoEl.getAttribute("content") || precoEl.getAttribute("data-price") || precoEl.textContent || "";
        const pm = String(raw).match(/(\d{1,4}[,.]\d{2})/);
        if (pm) preco = pm[1];
      }
      if (!preco) {
        const precoMatch = texto.match(/(\d{1,4}[,.]\d{2})\s*€/);
        if (precoMatch) preco = precoMatch[1];
      }
      let editora = "";
      const edA = wrap?.querySelector('a[href*="/editora/"]');
      if (edA) {
        const t = limpar(edA.textContent || "");
        if (t.length >= 2 && t.length < 100) editora = t;
      }
      const isbnM = href.match(/[_-](97[89]\d{10})/i);
      guardar({
        titulo,
        preco,
        moeda: "EUR",
        link: href,
        editora,
        isbn: isbnM ? isbnM[1] : "",
      });
    }

    return resultados;
  });

  return dados.map((item) => ({
    titulo: (() => {
      const t = limparTitulo(item.titulo);
      return t || tituloDeSlugUrlWook(normalizarUrl(item.link)) || "";
    })(),
    preco: parsePreco(item.preco),
    link: normalizarUrl(item.link),
    editora:
      sanearNomeEditora(limparTexto(item.editora)) ||
      inferirEditoraDoTitulo(limparTitulo(item.titulo)) ||
      "Desconhecida",
    isbn: limparTexto(item.isbn),
    urlListagem,
  }));
}

async function extrairDetalhesLivro(page, urlLivroOuOpts) {
  const opts = typeof urlLivroOuOpts === "object" && urlLivroOuOpts !== null ? urlLivroOuOpts : {};
  const urlLivro = typeof urlLivroOuOpts === "string" ? urlLivroOuOpts : "";

  if (!opts.skipGoto) {
    if (!/\/livro\//i.test(urlLivro)) {
      const resolved = await abrirFichaLivro(page, { link: urlLivro });
      if (!resolved) throw new Error("Ficha nao encontrada");
    } else {
      await page.goto(urlLivro, { waitUntil: "domcontentloaded", timeout: DETALHE_TIMEOUT_MS });
    }
  }

  await page
    .waitForSelector('script[type="application/ld+json"], h1, [itemprop="price"]', {
      timeout: SCRAPER_FAST ? 8000 : 15000,
    })
    .catch(() => {});
  await esperar(getDetalheEsperaMs());
  if (!SCRAPER_FAST) {
    await scrollPagina(page);
    await esperar(300);
  }

  const detalhe = await page.evaluate(() => {
    const limpar = (v) => (v || "").replace(/\s+/g, " ").trim();
    const normalizarSep = (s) =>
      String(s || "")
        .replace(/\u00A0/g, " ")
        .replace(/[\u00B7\u2022\u2027\u2219\u22C5\u30FB‧⋅·]/g, "·");
    const limparBlocoEditoraWook = (raw) => {
      let v = limpar(normalizarSep(raw));
      if (!v) return "";
      const cutDashVer = v.search(/\s*-\s*ver\s+detalhes\b/i);
      if (cutDashVer > 0) v = limpar(v.slice(0, cutDashVer));
      const dot = v.search(/\s*·\s*/);
      if (dot > 0) v = limpar(v.slice(0, dot));
      v = v.replace(/\s+i\s+\d{1,3}[.,]\d{2}\s*€.*$/i, "").trim();
      v = v.replace(/\s+\d{1,3}[.,]\d{2}\s*€.*$/i, "").trim();
      v = v.replace(/\s+\d{1,2}\s*%\s*DESCONTO.*$/i, "").trim();
      v = v.replace(/\bDESCONTO\b.*$/i, "").trim();
      v = v.replace(/\bseja\s+o\s+primeiro\s+a\s+comentar\b.*$/i, "").trim();
      v = v.replace(/\bE(\s+E){2,}\b.*$/i, "").trim();
      v = v
        .replace(/\s+ver\s+detalhes\b.*/i, "")
        .replace(/\s+detalhes\s+do\s+produto\b.*/i, "")
        .replace(/\s+avalia[cç][aã]o\s+dos\s+leitores\b.*/i, "")
        .replace(/\s*\(?\s*\d+\s+coment[aá]rios?\s*\)?/gi, "")
        .replace(/\(\s*\d+\s*\)\s*/g, "")
        .replace(/\besgotado\b.*$/i, "")
        .replace(/\bn[aã]o\s+dispon[ií]vel\b.*$/i, "")
        .trim();
      v = v
        .replace(
          /\s*,\s*(janeiro|fevereiro|mar[cç]o|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro)\s+de\s+\d{4}\s*$/i,
          "",
        )
        .trim();
      return limpar(String(v).replace(/^[/|\\\s—–-]+/, "").trim());
    };
    const nomeDeSlugEditora = (href) => {
      const m = String(href || "").match(/\/editora\/([^/?#]+)/i);
      if (!m || !m[1]) return "";
      let slug = m[1];
      try {
        slug = decodeURIComponent(slug);
      } catch (_e) {
        /* ignore */
      }
      if (/^\d+$/i.test(slug)) return "";
      const nome = limpar(slug.replace(/[-_]+/g, " "));
      if (nome.length < 3 || nome.length > 80) return "";
      return nome
        .split(/\s+/)
        .filter(Boolean)
        .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
        .join(" ");
    };
    const extrairRelevante = (texto) => {
      const linhas = String(texto || "")
        .split(/\r?\n/)
        .map((l) => limpar(l))
        .filter((l) => Boolean(l) && l.length <= 180);
      const relevantes = linhas.filter((linha) =>
        /classificação temática|classificacao tematica|livros escolares|apoio escolar|pré-escolar|pre-escolar|ensino básico|ensino basico|secundário|secundario|\b[1-9]\s*[.º°o]?\s*ano\b|\b1[0-2]\s*[.º°o]?\s*ano\b|matem|portugu|hist|geograf|fisic|quim|biolog|franc|ingl|espanhol|filosof|ciencias|hgp|estudo do meio|educação visual|educacao visual|educação tecnológica|educacao tecnologica/i.test(
          linha,
        ),
      );
      return relevantes.join(" | ");
    };

    const textoOrganizacao = (x) => {
      if (!x) return "";
      if (typeof x === "string") return x.trim();
      if (typeof x === "object") {
        if (x.name) return String(x.name).trim();
        if (x.legalName) return String(x.legalName).trim();
        if (Array.isArray(x)) return x.map(textoOrganizacao).filter(Boolean).join(" | ");
      }
      return "";
    };

    const extrairNumPreco = (v) => {
      if (v == null || v === "") return 0;
      const n = Number.parseFloat(String(v).replace(",", "."));
      return Number.isFinite(n) && n >= 0 ? n : 0;
    };
    const melhorPreco = (atual, candidato) => {
      const a = extrairNumPreco(atual);
      const c = extrairNumPreco(candidato);
      if (c <= 0) return atual;
      if (a <= 0) return String(c);
      return String(Math.max(a, c));
    };
    const extrairPrecoDeOferta = (offer) => {
      if (!offer) return "";
      const fila = Array.isArray(offer) ? [...offer] : [offer];
      let max = 0;
      while (fila.length) {
        const o = fila.shift();
        if (!o || typeof o !== "object") continue;
        if (Array.isArray(o)) {
          fila.push(...o);
          continue;
        }
        const tipos = o["@type"];
        const tipArr = Array.isArray(tipos) ? tipos : tipos ? [tipos] : [];
        if (tipArr.includes("AggregateOffer") || o.lowPrice != null || o.highPrice != null) {
          for (const k of ["lowPrice", "highPrice", "price"]) {
            const n = extrairNumPreco(o[k]);
            if (n > max) max = n;
          }
          if (o.offers) fila.push(...(Array.isArray(o.offers) ? o.offers : [o.offers]));
        } else {
          const n = extrairNumPreco(o.price ?? o.lowPrice);
          if (n > max) max = n;
          if (o.priceSpecification) {
            const specs = Array.isArray(o.priceSpecification) ? o.priceSpecification : [o.priceSpecification];
            for (const s of specs) {
              const sn = extrairNumPreco(s?.price);
              if (sn > max) max = sn;
            }
          }
        }
      }
      return max > 0 ? String(max) : "";
    };
    const melhorPrecoEurosTexto = (texto) => {
      const vals = [];
      for (const m of String(texto || "").matchAll(/(\d{1,3}(?:[.,]\d{2}))\s*€/g)) {
        const n = Number.parseFloat(m[1].replace(",", "."));
        if (n >= 0.5 && n <= 499) vals.push(n);
      }
      return vals.length ? String(Math.max(...vals)) : "";
    };

    const scripts = Array.from(document.querySelectorAll("script[type='application/ld+json']"));
    let tituloJsonLd = "";
    let editora = "";
    let isbn = "";
    let preco = "";
    let precoTexto = "";
    const orgNames = [];
    const visitarJson = (node) => {
      if (!node || typeof node !== "object") return;
      if (Array.isArray(node)) return node.forEach(visitarJson);
      if (node["@graph"]) visitarJson(node["@graph"]);
      const types = node["@type"];
      const typArr = Array.isArray(types) ? types : types ? [types] : [];
      if (typArr.some((x) => x === "Organization" || x === "Brand" || x === "Corporation")) {
        const on = textoOrganizacao(node);
        const onL = limparBlocoEditoraWook(on);
        if (onL && onL.length > 2 && onL.length < 120) orgNames.push(onL);
        else if (on && on.length > 2 && on.length < 120) orgNames.push(limpar(on));
      }
      if (typArr.includes("Product") || (node.name && node.offers)) {
        tituloJsonLd = tituloJsonLd || limpar(node.name || "");
        const ed =
          textoOrganizacao(node.brand) ||
          textoOrganizacao(node.publisher) ||
          textoOrganizacao(node.manufacturer) ||
          textoOrganizacao(node.producer);
        editora = editora || limparBlocoEditoraWook(limpar(ed));
        isbn = isbn || limpar(node.isbn || node.gtin13 || node.gtin || "");
        preco = melhorPreco(preco, extrairPrecoDeOferta(node.offers));
      }
      if (typArr.includes("Offer") || typArr.includes("AggregateOffer")) {
        preco = melhorPreco(preco, extrairPrecoDeOferta(node));
      }
      Object.values(node).forEach((v) => {
        if (v && typeof v === "object") visitarJson(v);
      });
    };
    for (const script of scripts) {
      try {
        visitarJson(JSON.parse(script.textContent || "{}"));
      } catch (_e) {
        /* ignora */
      }
    }

    try {
      const nextEl = document.getElementById("__NEXT_DATA__");
      if (nextEl) {
        const raw = nextEl.textContent || "";
        for (const m of raw.matchAll(
          /"(?:price|salePrice|currentPrice|pvp|Preco|preco|PrecoVenda|priceWithTax)"\s*:\s*(\d+(?:\.\d+)?)/gi,
        )) {
          preco = melhorPreco(preco, m[1]);
        }
        for (const m of raw.matchAll(/"editora"\s*:\s*"([^"]{2,80})"/gi)) {
          editora = editora || limparBlocoEditoraWook(m[1]);
        }
        for (const m of raw.matchAll(/"publisher(?:Name)?"\s*:\s*"([^"]{2,80})"/gi)) {
          editora = editora || limparBlocoEditoraWook(m[1]);
        }
      }
    } catch (_e) {
      /* ignore */
    }

    try {
      const dl = window.dataLayer || [];
      for (const item of dl) {
        const blocos = [
          item?.ecommerce?.detail?.products,
          item?.ecommerce?.add?.products,
          item?.ecommerce?.impressions,
          item?.products,
        ];
        for (const prods of blocos) {
          if (!Array.isArray(prods)) continue;
          for (const p of prods) {
            preco = melhorPreco(preco, p?.price);
            const br = p?.brand || p?.publisher || p?.editora;
            if (br) editora = editora || limparBlocoEditoraWook(String(br));
          }
        }
      }
    } catch (_e) {
      /* ignore */
    }

    const descricaoCurta = Array.from(document.querySelectorAll("meta[name='description']"))
      .map((m) => limpar(m.getAttribute("content") || ""))
      .filter(Boolean)
      .join(" ");

    const tituloRUidoso = (s) => {
      const x = limpar(s);
      if (!x || x.length < 4) return true;
      if (/^\d{1,2}\s*%\s*$/i.test(x)) return true;
      if (/^[\d.,\s€%|]+$/i.test(x) && x.length <= 14) return true;
      if (x.length <= 10 && /\d{1,2}\s*%/.test(x) && !/\b(ano|º|volume|livro|caderno|manual|portugu|matem|hist|ingl|exame|fich|prep)\b/i.test(x)) {
        return true;
      }
      return false;
    };
    const stripMarcaSite = (s) =>
      limpar(String(s || "").replace(/\s*[\-|–]\s*Wook.*$/i, "").replace(/\s*\|\s*Wook.*$/i, ""));

    const candidatosTitulo = [];
    const pushTit = (raw) => {
      const x = stripMarcaSite(raw || "");
      if (!tituloRUidoso(x) && x.length >= 4) candidatosTitulo.push(x);
    };
    for (const m of [
      document.querySelector('meta[property="og:title"]')?.getAttribute("content"),
      document.querySelector('meta[name="twitter:title"]')?.getAttribute("content"),
    ]) {
      pushTit(m || "");
    }
    const itempropName = document.querySelector('[itemprop="name"]');
    if (itempropName) {
      pushTit(itempropName.getAttribute("content"));
      pushTit(itempropName.textContent);
    }
    document.querySelectorAll("h1").forEach((h) => pushTit(h.textContent));
    const docTitle = stripMarcaSite(document.querySelector("title")?.textContent || "");
    pushTit(docTitle);
    if (!tituloRUidoso(tituloJsonLd) && tituloJsonLd.length >= 4) candidatosTitulo.push(tituloJsonLd);
    const validos = candidatosTitulo.filter((x) => !tituloRUidoso(x) && x.length >= 6);
    let titulo =
      (validos.length ? validos.sort((a, b) => b.length - a.length)[0] : null) ||
      candidatosTitulo.find((x) => !tituloRUidoso(x)) ||
      tituloJsonLd ||
      docTitle ||
      "";
    if ((!titulo || tituloRUidoso(titulo)) && descricaoCurta) {
      const snip = limpar((descricaoCurta || "").split(/[.·\n]/)[0] || "");
      if (snip.length >= 12 && snip.length < 280 && !/^[\d.,\s€%]+$/i.test(snip)) titulo = snip;
    }

    const breadcrumb = Array.from(document.querySelectorAll("nav a, .breadcrumb a, [class*='breadcrumb'] a"))
      .map((a) => limpar(a.textContent || ""))
      .filter(Boolean);

    const extrairPrecoDom = () => {
      const seletores = [
        '[itemprop="price"]',
        '[data-testid*="price" i]',
        '[class*="sales-price" i]',
        '[class*="sale-price" i]',
        '[class*="current-price" i]',
        '[class*="product-price" i]',
        '[class*="preco" i]',
        ".price",
      ];
      for (const sel of seletores) {
        const el = document.querySelector(sel);
        if (!el) continue;
        const raw =
          el.getAttribute("content") || el.getAttribute("data-price") || el.textContent || "";
        const m = String(raw).match(/(\d{1,4}[,.]\d{2})/);
        if (m) {
          const n = Number.parseFloat(m[1].replace(",", "."));
          if (n >= 0.5 && n < 500) return m[1];
        }
      }
      for (const meta of document.querySelectorAll(
        'meta[property="product:price:amount"], meta[property="og:price:amount"]',
      )) {
        const c = limpar(meta.getAttribute("content") || "");
        if (/^\d/.test(c)) return c;
      }
      return "";
    };

    if (!preco) preco = extrairPrecoDom();

    const textoPagina = limpar(document.body?.innerText || "");
    const textoRelevante = extrairRelevante(document.body?.innerText || "");
    precoTexto = melhorPrecoEurosTexto(textoPagina);
    if (!preco && precoTexto) preco = precoTexto;
    if (extrairNumPreco(preco) <= 0 && precoTexto) preco = precoTexto;
    const zonaPreco = document.querySelector(
      '[class*="price" i], [class*="preco" i], [itemprop="offers"], main, [role="main"]',
    );
    if (zonaPreco) {
      const pZona = melhorPrecoEurosTexto(zonaPreco.innerText || "");
      if (pZona) preco = melhorPreco(preco, pZona);
    }
    const classificacaoMatch = (textoRelevante || textoPagina).match(/Classificação Temática:\s*([^\n|]+)/i);
    const anoCampo =
      Array.from(document.querySelectorAll("dt, th, strong, b"))
        .map((n) => limpar(n.textContent || ""))
        .find((t) => /ano.*escolar|escolaridade|ano/i.test(t)) || "";

    let editoraDom = "";
    const metaBrand = document.querySelector('meta[property="product:brand"], meta[name="product:brand"]');
    if (metaBrand) editoraDom = limparBlocoEditoraWook(metaBrand.getAttribute("content") || "");

    const dts = Array.from(document.querySelectorAll("dt"));
    for (const dt of dts) {
      const t = limpar(dt.textContent || "");
      if (/editora|editor\b|marca|publisher/i.test(t)) {
        const dd = dt.nextElementSibling;
        if (dd && String(dd.tagName || "").toUpperCase() === "DD") {
          const v = limparBlocoEditoraWook(dd.textContent || "");
          if (v.length >= 2 && v.length < 200) {
            editoraDom = editoraDom || v;
            break;
          }
        }
      }
    }

    if (!editoraDom) {
      const anchors = Array.from(document.querySelectorAll('a[href*="/editora/"]'));
      for (const a of anchors) {
        const txt = limparBlocoEditoraWook(a.textContent || "");
        if (
          txt.length >= 3 &&
          txt.length < 100 &&
          !/^ver\s+/i.test(txt) &&
          !/^wook$/i.test(txt) &&
          !/detalhes|avalia[cç]/i.test(txt)
        ) {
          editoraDom = txt;
          break;
        }
      }
      if (!editoraDom) {
        for (const a of anchors) {
          const slugNome = nomeDeSlugEditora(a.getAttribute("href") || "");
          if (slugNome) {
            editoraDom = slugNome;
            break;
          }
        }
      }
    }

    const itempropBrand = document.querySelector('[itemprop="brand"]');
    if (itempropBrand) {
      const v = limparBlocoEditoraWook(itempropBrand.textContent || itempropBrand.getAttribute("content") || "");
      if (v.length >= 2) editoraDom = editoraDom || v;
    }

    if (!editoraDom) {
      const cand = document.querySelector(
        "[data-publisher], [data-brand], [data-editor], .publisher, .book-publisher, .product-brand, .editora-livro, .editora",
      );
      if (cand) {
        const v = limparBlocoEditoraWook(
          cand.textContent || cand.getAttribute("data-publisher") || cand.getAttribute("data-brand") || "",
        );
        if (v.length >= 2 && v.length < 150) editoraDom = editoraDom || v;
      }
    }

    if (!editoraDom) {
      const rxs = [
        /Editora\s*[:\-]?\s*([^\n|·]{3,120})/i,
        /\bEditor\s*[:\-]?\s*([^\n|·]{3,120})/i,
        /Publicad[oa]\s+por\s*[:\-]?\s*([^\n|·]{3,120})/i,
        /Marca\s*[:\-]?\s*([^\n|·]{3,120})/i,
      ];
      for (const rx of rxs) {
        const m = textoPagina.match(rx);
        if (m && m[1]) {
          editoraDom = limparBlocoEditoraWook(limpar(m[1].split(/\s{2,}/)[0]));
          if (editoraDom.length >= 2) break;
        }
      }
    }

    let tipoWook = "";
    for (const dt of document.querySelectorAll("dt")) {
      const t = limpar(dt.textContent || "");
      if (/^tipo\b|formato\b|categoria\b/i.test(t)) {
        const dd = dt.nextElementSibling;
        if (dd) tipoWook = limpar(dd.textContent || "");
      }
    }

    const orgFallback = orgNames.find((n) => !/wook|fnac|iberlibro/i.test(n)) || orgNames[0] || "";
    let editoraFinal = limparBlocoEditoraWook(limpar(editoraDom || orgFallback || editora));
    const lixoEd = /ver\s+detalhes|€|\bDESCONTO\b|avalia[cç]|coment[aá]rio/i;
    if (!editoraFinal || editoraFinal.replace(/^[,.\s]+/, "").length < 2 || lixoEd.test(editoraFinal)) {
      for (const a of document.querySelectorAll('a[href*="/editora/"]')) {
        const slugNome = nomeDeSlugEditora(a.getAttribute("href") || "");
        if (slugNome) {
          editoraFinal = slugNome;
          break;
        }
      }
    }

    return {
      titulo,
      editora: editoraFinal,
      isbn,
      preco,
      precoTexto,
      breadcrumb,
      textoPagina,
      textoRelevante,
      descricaoCurta,
      classificacaoTematica: limpar(classificacaoMatch?.[1] || ""),
      anoCampo,
      tipoWook,
    };
  });

  const textoBase = textoMetaLivro({}, detalhe);

  const tituloFinal = limparTitulo(limparTexto(detalhe.titulo));
  const edSan = sanearNomeEditora(detalhe.editora);
  const editoraBruta = edSan || inferirEditoraDoTitulo(tituloFinal) || "Desconhecida";

  return {
    titulo: tituloFinal,
    editora: editoraBruta,
    isbn: limparTexto(detalhe.isbn),
    preco: parsePreco(detalhe.preco) || parsePreco(detalhe.precoTexto),
    tipo: mapearTipo(textoBase),
    disciplina: mapearDisciplina(textoBase),
    anoEscolar: mapearAnoEscolar(`${detalhe.anoCampo} ${textoBase}`),
  };
}

async function extrairLinksEscolaresDaPagina(page) {
  const links = await page.evaluate(() => {
    const candidatos = [];
    const palavras = ["escolar", "educa", "manual", "caderno", "exame", "ensino", " ano"];
    const anchors = Array.from(document.querySelectorAll("a[href]"));
    for (const a of anchors) {
      const href = (a.getAttribute("href") || "").trim();
      const texto = (a.textContent || "").trim();
      const base = `${href} ${texto}`.toLowerCase();
      if (!href || href.startsWith("#")) continue;
      if (palavras.some((p) => base.includes(p))) {
        const titleAttr = (a.getAttribute("title") || "").trim();
        const aria = (a.getAttribute("aria-label") || "").trim();
        candidatos.push({ href, label: texto || titleAttr || aria });
      }
    }
    const unicos = [];
    const vistos = new Set();
    for (const item of candidatos) {
      const chave = `${item.href}|${item.label}`;
      if (vistos.has(chave)) continue;
      vistos.add(chave);
      unicos.push(item);
    }
    return unicos;
  });

  return links
    .map((item) => ({
      url: normalizarUrl(item.href),
      label: limparTexto(item.label),
    }))
    .filter((item) => /livros-escolares|apoio-escolar|\/arvoretematica\//i.test(item.url))
    .filter((item) => !/pre-escolar|pré-escolar/i.test(item.url))
    .filter((item) =>
      /\b([1-9]|1[0-2])\s*[.º°o]?\s*ano\b|apoio escolar|livros escolares|ensino basico|ensino básico|secundário|secundario/i.test(
        `${item.label} ${item.url}`,
      ),
    )
    .slice(0, 48);
}

async function extrairContextoSecao(page) {
  return page.evaluate(() => {
    const limpar = (v) => (v || "").replace(/\s+/g, " ").trim();
    const h1 = limpar(document.querySelector("h1")?.textContent || "");
    const breadcrumb = Array.from(document.querySelectorAll(".breadcrumb a, nav[aria-label*='breadcrumb'] a, nav a"))
      .map((a) => limpar(a.textContent || ""))
      .filter(Boolean)
      .slice(-8);
    return { h1, breadcrumb };
  });
}

async function atualizarLivrosNaBd(connection, livros) {
  if (!livros?.length) return 0;
  let atualizados = 0;
  for (const livro of livros) {
    if (!livro?.id) continue;
    const editora = resolverEditoraFinal(livro);
    const preco = Number(livro.preco) || 0;
    const titulo = String(livro.titulo || "").slice(0, 255);
    await connection.execute(
      `
      UPDATE livros SET
        editora = CASE
          WHEN ? <> '' AND LOWER(?) NOT IN ('desconhecida', 'não indicada', 'nao indicada')
          THEN ? ELSE editora END,
        preco = CASE WHEN ? > 0 THEN ? ELSE preco END,
        titulo = CASE WHEN CHAR_LENGTH(?) > CHAR_LENGTH(COALESCE(titulo, '')) THEN ? ELSE titulo END,
        updated_at = NOW()
      WHERE id = ?
      `,
      [editora, editora, editora, preco, preco, titulo, titulo, livro.id],
    );
    atualizados += 1;
  }
  return atualizados;
}

async function reclassificarMetadadosNaBd(connection) {
  console.log("A reclassificar tipo e disciplina (todos os livros)...");

  await connection.execute(
    `
    UPDATE livros SET
      tipo = CASE
        WHEN LOWER(titulo) REGEXP 'caderno[[:space:]]+de[[:space:]]+(atividades|apoio)' THEN 'CADERNO_ATIVIDADES'
        WHEN LOWER(titulo) REGEXP 'fichas?[[:space:]]+de' THEN 'CADERNO_ATIVIDADES'
        WHEN LOWER(titulo) LIKE '%provas de exame%' OR LOWER(titulo) LIKE '%prova de exame%' THEN 'CADERNO_ATIVIDADES'
        WHEN LOWER(titulo) LIKE '%preparar os testes%' OR LOWER(titulo) LIKE '%preparar testes%' THEN 'CADERNO_ATIVIDADES'
        WHEN LOWER(titulo) LIKE '%testes e exame%' THEN 'CADERNO_ATIVIDADES'
        WHEN LOWER(titulo) LIKE '%guia de estudo%' THEN 'CADERNO_ATIVIDADES'
        WHEN LOWER(titulo) LIKE '%apontamentos%' THEN 'CADERNO_ATIVIDADES'
        WHEN LOWER(titulo) LIKE '%resumos -%' OR LOWER(titulo) LIKE '%resumo -%' THEN 'CADERNO_ATIVIDADES'
        WHEN LOWER(titulo) LIKE '%caderno%' AND LOWER(titulo) LIKE '%atividades%' THEN 'CADERNO_ATIVIDADES'
        WHEN LOWER(titulo) LIKE '%infantil%' OR LOWER(titulo) LIKE '%pre-escolar%' THEN 'INFANTIL'
        WHEN LOWER(titulo) LIKE '%python%' OR LOWER(titulo) LIKE '%sql%' THEN 'TECNICO'
        WHEN LOWER(titulo) LIKE '%manual%' THEN 'MANUAL'
        ELSE 'MANUAL'
      END,
      updated_at = NOW()
    WHERE deleted_at IS NULL
    `,
  );

  await connection.execute(
    `
    UPDATE livros SET
      disciplina = CASE
        WHEN LOWER(titulo) LIKE '%estudo do meio%' THEN 'Estudo do Meio'
        WHEN LOWER(titulo) LIKE '%historia e geografia%' OR LOWER(titulo) LIKE '% hgp %' OR LOWER(titulo) LIKE 'hgp %' THEN 'Historia e Geografia de Portugal'
        WHEN LOWER(titulo) LIKE '%educacao visual%' OR LOWER(titulo) LIKE '%ed. visual%' THEN 'Educacao Visual'
        WHEN LOWER(titulo) LIKE '%educacao tecnologica%' THEN 'Educacao Tecnologica'
        WHEN LOWER(titulo) LIKE '%educacao musical%' THEN 'Educacao Musical'
        WHEN LOWER(titulo) LIKE '%educacao fisica%' OR LOWER(titulo) LIKE '%ed. fisica%' THEN 'Educacao Fisica'
        WHEN LOWER(titulo) LIKE '%economia%' THEN 'Economia'
        WHEN LOWER(titulo) LIKE '%filosofia%' THEN 'Filosofia'
        WHEN LOWER(titulo) LIKE '%portugu%' AND LOWER(titulo) NOT LIKE '%portugal%' THEN 'Portugues'
        WHEN LOWER(titulo) LIKE '%matemat%' OR LOWER(titulo) LIKE '%macs%' THEN 'Matematica'
        WHEN LOWER(titulo) LIKE '%ingles%' OR LOWER(titulo) LIKE '%inglês%' THEN 'Ingles'
        WHEN LOWER(titulo) LIKE '%frances%' OR LOWER(titulo) LIKE '%francês%' THEN 'Frances'
        WHEN LOWER(titulo) LIKE '%espanhol%' THEN 'Espanhol'
        WHEN LOWER(titulo) LIKE '%geograf%' THEN 'Geografia'
        WHEN LOWER(titulo) LIKE '%fisico-quimica%' OR LOWER(titulo) LIKE '%fisico quimica%' OR LOWER(titulo) LIKE '%fisica e quimica%' THEN 'Fisico-Quimica'
        WHEN LOWER(titulo) LIKE '%fisic%' OR LOWER(titulo) LIKE '%quim%' THEN 'Fisico-Quimica'
        WHEN LOWER(titulo) LIKE '%biolog%' THEN 'Biologia'
        WHEN LOWER(titulo) LIKE '%hist%' THEN 'Historia'
        WHEN LOWER(titulo) LIKE '%ciencias%' OR LOWER(titulo) LIKE '%ciências%' THEN 'Ciencias'
        ELSE COALESCE(NULLIF(TRIM(disciplina), ''), 'Educacao')
      END,
      updated_at = NOW()
    WHERE deleted_at IS NULL
    `,
  );

  const [[stats]] = await connection.execute(
    `
    SELECT
      SUM(UPPER(COALESCE(tipo,'')) = 'MANUAL') AS manuais,
      SUM(UPPER(COALESCE(tipo,'')) = 'CADERNO_ATIVIDADES') AS cadernos,
      COUNT(DISTINCT disciplina) AS disciplinas
    FROM livros WHERE deleted_at IS NULL
    `,
  );
  console.log(
    `Apos reclassificar: ${stats.manuais} manuais, ${stats.cadernos} cadernos, ${stats.disciplinas} disciplinas distintas.`,
  );
}

async function imprimirStatsBd(connection) {
  const [zero] = await connection.execute(
    "SELECT COUNT(*) AS c FROM livros WHERE deleted_at IS NULL AND (preco IS NULL OR preco <= 0)",
  );
  const [badEd] = await connection.execute(
    "SELECT COUNT(*) AS c FROM livros WHERE deleted_at IS NULL AND (editora IS NULL OR TRIM(editora) = '' OR LOWER(TRIM(editora)) = 'desconhecida')",
  );
  const [total] = await connection.execute("SELECT COUNT(*) AS c FROM livros WHERE deleted_at IS NULL");
  console.log(
    `BD: ${total[0].c} livros | sem preco: ${zero[0].c} | editora em falta: ${badEd[0].c}`,
  );
}

async function criarBrowser() {
  return puppeteer.launch({
    headless: true,
    defaultViewport: { width: 1280, height: 800 },
    args: [
      "--disable-dev-shm-usage",
      "--disable-gpu",
      "--no-sandbox",
      "--disable-setuid-sandbox",
      "--disable-extensions",
      "--disable-background-networking",
      "--disable-default-apps",
    ],
  });
}

async function mainBackfill() {
  const browser = await criarBrowser();
  const connection = await mysql.createConnection(DB_CONFIG);

  try {
    const [rows] = await connection.execute(
      `
      SELECT id, titulo, isbn, codigo_interno, preco, editora, disciplina, ano_escolar, tipo
      FROM livros
      WHERE deleted_at IS NULL
        AND (
          preco IS NULL OR preco <= 0
          OR editora IS NULL OR TRIM(editora) = ''
          OR LOWER(TRIM(editora)) = 'desconhecida'
        )
      ORDER BY id
      `,
    );

    const livros = rows.map((r) => ({
      id: r.id,
      titulo: r.titulo,
      isbn: r.isbn,
      codigo_interno: r.codigo_interno,
      preco: Number(r.preco) || 0,
      editora: r.editora,
      disciplina: r.disciplina,
      anoEscolar: r.ano_escolar,
      tipo: r.tipo,
      link: construirLinkWook({ titulo: r.titulo, isbn: r.isbn }),
    }));

    if (rows.length === 0) {
      console.log("Tabela livros vazia — modo rapido (~10-15 min)...");
      await connection.end();
      await browser.close();
      PERFIL_BD_VAZIA = true;
      return main();
    }

    console.log(`Modo BACKFILL: ${livros.length} registos a corrigir (sem repetir listagens Wook).`);
    await imprimirStatsBd(connection);

    let gravados = 0;
    await enriquecerLivrosComDetalhes(browser, livros, async (lote) => {
      gravados += await atualizarLivrosNaBd(connection, lote);
      if (gravados % 100 < 25) console.log(`  Atualizados na BD: ${gravados}`);
    });

    console.log(`Backfill concluido: ${gravados} registos atualizados.`);
    await imprimirStatsBd(connection);
  } finally {
    await connection.end();
    await browser.close();
  }
}

async function upsertLivrosLote(connection, livros, defaults = {}) {
  const disciplinaPadrao = defaults.disciplinaPadrao || "Educacao";
  const anoEscolarPadrao = Number.isFinite(Number(defaults.anoEscolarPadrao)) ? Number(defaults.anoEscolarPadrao) : 0;
  const tipoPadrao = defaults.tipoPadrao || "MANUAL";

  const sql = `
    INSERT INTO livros
    (editora, disciplina, ano_escolar, tipo, titulo, isbn, codigo_interno, preco, ativo, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, NOW(), NOW())
    ON DUPLICATE KEY UPDATE
      editora = CASE
        WHEN VALUES(editora) IS NOT NULL AND TRIM(VALUES(editora)) <> ''
          AND LOWER(TRIM(VALUES(editora))) NOT IN ('desconhecida', 'não indicada', 'nao indicada')
        THEN VALUES(editora)
        ELSE editora
      END,
      disciplina = VALUES(disciplina),
      ano_escolar = VALUES(ano_escolar),
      tipo = VALUES(tipo),
      preco = CASE WHEN VALUES(preco) > 0 THEN VALUES(preco) ELSE preco END,
      titulo = CASE
        WHEN CHAR_LENGTH(VALUES(titulo)) > CHAR_LENGTH(COALESCE(titulo, '')) THEN VALUES(titulo)
        ELSE titulo
      END,
      updated_at = NOW(),
      deleted_at = NULL
  `;

  let inseridos = 0;
  for (const livro of livros) {
    if (!temDadosMinimos(livro)) continue;
    const isbnFinal = livro.isbn || isbnDoLinkWook(livro.link) || gerarIsbnFallback(livro.link, livro.titulo);
    const codigoInterno =
      (livro.link || "").split("/").filter(Boolean).pop()?.slice(0, 50) || livro.codigo_interno || null;

    await connection.execute(sql, [
      resolverEditoraFinal(livro),
      livro.disciplina || disciplinaPadrao,
      Number.isFinite(Number(livro.anoEscolar)) ? Number(livro.anoEscolar) : anoEscolarPadrao,
      (() => {
        const t =
          (livro.tipo && String(livro.tipo).trim()) ||
          mapearTipo(`${livro.titulo || ""} ${livro.disciplina || ""} ${livro.contextoSecao || ""}`) ||
          tipoPadrao;
        return String(t).toUpperCase().trim();
      })(),
      livro.titulo.slice(0, 255),
      isbnFinal.slice(0, 20),
      codigoInterno,
      Number(livro.preco) || 0,
    ]);
    inseridos += 1;
  }
  return inseridos;
}

async function guardarNoMySql(livros) {
  const connection = await mysql.createConnection(DB_CONFIG);
  try {
    const [rows] = await connection.execute(
      `
        SELECT disciplina, ano_escolar, tipo
        FROM livros
        WHERE (disciplina IS NOT NULL AND disciplina <> '')
           OR ano_escolar IS NOT NULL
           OR (tipo IS NOT NULL AND tipo <> '')
        ORDER BY updated_at DESC
        LIMIT 1
      `,
    );

    const defaults = rows?.[0] || {};
    const inseridos = await upsertLivrosLote(connection, livros, {
      disciplinaPadrao: "Educacao",
      anoEscolarPadrao: Number.isFinite(Number(defaults.ano_escolar)) ? Number(defaults.ano_escolar) : 0,
      tipoPadrao: "MANUAL",
    });

    await reclassificarMetadadosNaBd(connection);

    if (APAGAR_NAO_ESCOLARES) {
      // Opcional: limpeza destrutiva apenas quando ativada explicitamente por variavel de ambiente.
      await connection.execute(
        `
        DELETE FROM livros
        WHERE (disciplina IS NULL OR LOWER(disciplina) NOT IN ('educacao', 'educação'))
           OR (tipo IS NOT NULL AND UPPER(tipo) NOT IN ('MANUAL', 'CADERNO_ATIVIDADES', 'TECNICO', 'INFANTIL'))
        `,
      );
    }

    // Corrige registos antigos que ficaram com tipo "ROMANCE" apesar de serem escolares.
    await connection.execute(
      `
      UPDATE livros
      SET tipo = 'MANUAL',
          disciplina = CASE
            WHEN LOWER(CONCAT_WS(' ', titulo, editora, codigo_interno, isbn)) LIKE '%portugu%' THEN 'Portugues'
            WHEN LOWER(CONCAT_WS(' ', titulo, editora, codigo_interno, isbn)) LIKE '%matemat%' THEN 'Matematica'
            WHEN LOWER(CONCAT_WS(' ', titulo, editora, codigo_interno, isbn)) LIKE '%ingl%' THEN 'Ingles'
            WHEN LOWER(CONCAT_WS(' ', titulo, editora, codigo_interno, isbn)) LIKE '%franc%' THEN 'Frances'
            WHEN LOWER(CONCAT_WS(' ', titulo, editora, codigo_interno, isbn)) LIKE '%espanhol%' THEN 'Espanhol'
            WHEN LOWER(CONCAT_WS(' ', titulo, editora, codigo_interno, isbn)) LIKE '%hist%' THEN 'Historia'
            WHEN LOWER(CONCAT_WS(' ', titulo, editora, codigo_interno, isbn)) LIKE '%geograf%' THEN 'Geografia'
            WHEN LOWER(CONCAT_WS(' ', titulo, editora, codigo_interno, isbn)) LIKE '%fisic%'
              OR LOWER(CONCAT_WS(' ', titulo, editora, codigo_interno, isbn)) LIKE '%quim%' THEN 'Fisico-Quimica'
            WHEN LOWER(CONCAT_WS(' ', titulo, editora, codigo_interno, isbn)) LIKE '%biolog%' THEN 'Biologia'
            WHEN LOWER(CONCAT_WS(' ', titulo, editora, codigo_interno, isbn)) LIKE '%filosof%' THEN 'Filosofia'
            WHEN LOWER(CONCAT_WS(' ', titulo, editora, codigo_interno, isbn)) LIKE '%ciencias%'
              OR LOWER(CONCAT_WS(' ', titulo, editora, codigo_interno, isbn)) LIKE '%ciências%' THEN 'Ciencias'
            ELSE COALESCE(NULLIF(disciplina, ''), 'Educacao')
          END,
          updated_at = NOW()
      WHERE UPPER(COALESCE(tipo, '')) = 'ROMANCE'
        AND (
          COALESCE(ano_escolar, 0) BETWEEN 1 AND 12
          OR LOWER(CONCAT_WS(' ', titulo, editora, codigo_interno, isbn)) REGEXP '(manual|caderno|atividades|livro escolar|escolar|ensino|[[:<:]](1|2|3|4|5|6|7|8|9|10|11|12)[[:>:]]\\s*([.º°o-]?\\s*ano)|portugu|matemat|ingl|franc|espanhol|hist|geograf|fisic|quim|biolog|filosof|ciencias|hgp)'
        )
      `,
    );

    // Remove registos pobres que não têm literalmente nenhuma utilidade (sem titulo e sem link).
    // Mas preservamos os escolares mesmo sem preço/editora porque já passaram pelo filtro estrito.


    // Garante que sobram apenas livros escolares (remove lixo antigo de romance/literatura).
    await connection.execute(
      `
      DELETE FROM livros
      WHERE UPPER(COALESCE(tipo, '')) = 'ROMANCE'
         OR LOWER(COALESCE(disciplina, '')) = 'literatura'
      `,
    );

    return inseridos;
  } finally {
    await connection.end();
  }
}

async function contarLivrosNaBd() {
  const connection = await mysql.createConnection(DB_CONFIG);
  try {
    const [rows] = await connection.execute("SELECT COUNT(*) AS c FROM livros WHERE deleted_at IS NULL");
    return Number(rows[0]?.c || 0);
  } finally {
    await connection.end();
  }
}

async function main() {
  if (PERFIL_BD_VAZIA) {
    console.log("Modo RAPIDO (~10-15 min): BD estava vazia — listagens + fichas com preco/editora.");
  } else {
    console.log("Modo COMPLETO: listagens Wook + fichas (preco e editora)...");
  }
  const browser = await criarBrowser();

  try {
    const page = await browser.newPage();
    await configurarPaginaListagem(page);

    const livrosColetados = [];
    const chaves = new Set();
    const secoesVisitadas = new Set();

    const maxPag = getMaxPaginasListagem();
    for (const url of URLS_WOOK) {
      for (let pag = 1; pag <= maxPag; pag += 1) {
        const pageUrl = urlComPagina(url, pag);
        console.log(`A ler: ${pageUrl}`);
        await page.goto(pageUrl, { waitUntil: "domcontentloaded", timeout: 60000 });
        if (pag === 1) await aceitarCookies(page);
        await page
          .waitForSelector('a[href*="/livro/"], script[type="application/ld+json"]', { timeout: 20000 })
          .catch(() => {});
        await scrollPagina(page);
        await esperar(pag === 1 ? (PERFIL_BD_VAZIA ? 900 : ESPERA_ENTRE_PAGINAS_MS) : 600);

        const livrosPagina = await extrairLivrosDaPagina(page, pageUrl);
        let novosNesta = 0;
        for (const livro of livrosPagina) {
          const chave = `${livro.titulo}|${livro.link}`;
          if (chaves.has(chave)) continue;
          chaves.add(chave);
          novosNesta += 1;
          livrosColetados.push(livro);
        }

        if (pag === 1 && !SKIP_SECOES_EXTRA) {
          const linksEscolares = await extrairLinksEscolaresDaPagina(page);
          for (const linkEscolar of linksEscolares) {
            if (secoesVisitadas.has(linkEscolar.url)) continue;
            secoesVisitadas.add(linkEscolar.url);
            console.log(`A ler secao escolar: ${linkEscolar.url}`);
            await page.goto(linkEscolar.url, { waitUntil: "domcontentloaded", timeout: 60000 });
            await scrollPagina(page);
            await esperar(1800);
            const contextoSecao = await extrairContextoSecao(page);
            const livrosEscolaresPagina = await extrairLivrosDaPagina(page, linkEscolar.url);
            for (const livro of livrosEscolaresPagina) {
              const chave = `${livro.titulo}|${livro.link}`;
              if (chaves.has(chave)) continue;
              chaves.add(chave);
              livrosColetados.push({
                ...livro,
                contextoSecao: `${linkEscolar.label || ""} ${contextoSecao.h1 || ""} ${(contextoSecao.breadcrumb || []).join(" ")}`,
              });
            }
          }
        }

        if (pag > 1 && novosNesta === 0) break;
      }
    }

    console.log(`Livros extraidos: ${livrosColetados.length}`);
    const livrosEscolares = livrosColetados.filter(ehLivroEscolar);
    console.log(`Livros escolares filtrados: ${livrosEscolares.length}`);
    if (livrosEscolares.length === 0) throw new Error("Nao foram encontrados livros escolares.");
    const livrosEnriquecidos = livrosEscolares.map((livro) => ({
      ...livro,
      titulo: escolherTituloFinal(livro.titulo) || tituloDeSlugUrlWook(livro.link) || "",
      tipo: mapearTipo(`${livro.titulo} ${livro.contextoSecao || ""}`),
      disciplina: mapearDisciplina(`${livro.titulo} ${livro.contextoSecao || ""}`),
      anoEscolar: mapearAnoEscolar(`${livro.titulo} ${livro.contextoSecao || ""}`),
      editora: sanearNomeEditora(livro.editora) || inferirEditoraDoTitulo(limparTitulo(livro.titulo)) || "Desconhecida",
    }));
    for (const l of livrosEnriquecidos) {
      l.anoEscolar = resolverAnoEscolarFinal(l);
      l.editora = resolverEditoraFinal(l);
    }
    const livrosFinais = livrosEnriquecidos.filter(ehLivroEscolarEstrito).filter(livroAnoPermitido);
    console.log(
      `Livros apos filtro estrito e ano 1-12 (${APENAS_ANOS_1_A_12 ? "ativo" : "desativado"}): ${livrosFinais.length}`,
    );

    let connectionIncremental;
    await enriquecerLivrosComDetalhes(
      browser,
      livrosFinais,
      GRAVAR_INCREMENTAL
        ? async (lote) => {
            if (!connectionIncremental) connectionIncremental = await mysql.createConnection(DB_CONFIG);
            await upsertLivrosLote(connectionIncremental, lote);
            const n = await connectionIncremental.execute("SELECT COUNT(*) AS c FROM livros WHERE deleted_at IS NULL");
            console.log(`  Na BD: ${n[0][0].c} livros`);
          }
        : null,
      { forceAll: !PERFIL_BD_VAZIA },
    );
    if (connectionIncremental) await connectionIncremental.end();

    for (const l of livrosFinais) {
      if (!l.isbn) l.isbn = isbnDoLinkWook(l.link);
      l.editora = resolverEditoraFinal(l);
    }

    const comPreco = livrosFinais.filter((l) => Number(l.preco) > 0).length;
    const comEditora = livrosFinais.filter(
      (l) => l.editora && String(l.editora).toLowerCase() !== "desconhecida",
    ).length;
    console.log(`Com preco > 0: ${comPreco}/${livrosFinais.length}; com editora: ${comEditora}/${livrosFinais.length}`);

    require("fs").writeFileSync("livros_finais_dump.json", JSON.stringify(livrosFinais, null, 2));
    const totalInseridos = await guardarNoMySql(livrosFinais);
    console.log(`Registos inseridos/atualizados na BD: ${totalInseridos}`);
    console.log(
      "Nota: 'Livros escolares filtrados' = desta corrida antes de gravar. O site mostra o total de linhas na tabela livros (inclui corridas anteriores e livros que ja la estavam).",
    );
  } finally {
    await browser.close();
  }
}

async function mainReclassify() {
  const connection = await mysql.createConnection(DB_CONFIG);
  try {
    await imprimirStatsBd(connection);
    await reclassificarMetadadosNaBd(connection);
    await imprimirStatsBd(connection);
  } finally {
    await connection.end();
  }
}

async function iniciar() {
  if (SCRAPER_MODE === "reclassify") {
    return mainReclassify();
  }
  if (SCRAPER_MODE === "full") {
    const n = await contarLivrosNaBd();
    if (n === 0) PERFIL_BD_VAZIA = true;
    return main();
  }
  if (SCRAPER_MODE === "backfill") {
    const n = await contarLivrosNaBd();
    if (n === 0) {
      PERFIL_BD_VAZIA = true;
      return main();
    }
    return mainBackfill();
  }
  return main();
}

iniciar().catch((erro) => {
  console.error("Erro no scraper:", erro.message);
  process.exit(1);
});