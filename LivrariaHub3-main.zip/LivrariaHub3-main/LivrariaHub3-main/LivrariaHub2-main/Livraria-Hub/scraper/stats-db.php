<?php
$pdo = new PDO('mysql:host=127.0.0.1;dbname=livrariahub2', 'root', '');
$total = $pdo->query('SELECT COUNT(*) FROM livros')->fetchColumn();
$zero = $pdo->query('SELECT COUNT(*) FROM livros WHERE preco IS NULL OR preco <= 0')->fetchColumn();
$badEd = $pdo->query("SELECT COUNT(*) FROM livros WHERE editora IS NULL OR TRIM(editora) = '' OR LOWER(TRIM(editora)) = 'desconhecida'")->fetchColumn();
echo "total=$total zero_preco=$zero bad_editora=$badEd\n";
$stmt = $pdo->query("SELECT editora, COUNT(*) n, SUM(preco <= 0) z FROM livros GROUP BY editora ORDER BY z DESC LIMIT 15");
foreach ($stmt as $row) {
    echo "{$row['editora']} | n={$row['n']} | zero={$row['z']}\n";
}
