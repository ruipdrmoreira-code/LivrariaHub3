<?php $__env->startSection('title', 'Entrar — LivrariaHub'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Entrar</h1>
    <p class="lead">Inicia sessão para veres o catálogo de livros escolares.</p>

    <form method="POST" action="<?php echo e(route('login.store')); ?>">
        <?php echo csrf_field(); ?>
        <label for="email">Email</label>
        <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="username" autofocus>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <label for="password">Palavra-passe</label>
        <input id="password" type="password" name="password" required autocomplete="current-password">
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div class="check">
            <input id="remember" type="checkbox" name="remember">
            <label for="remember" style="margin:0;">Manter sessão</label>
        </div>

        <?php if($errors->any() && ! $errors->has('email') && ! $errors->has('password')): ?>
            <ul class="errors">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($err); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>

        <button type="submit" class="btn">Entrar</button>
    </form>

    <div class="links">
        <a href="<?php echo e(route('register')); ?>">Criar conta</a>
        <?php if(Route::has('password.request')): ?>
            &nbsp;·&nbsp;
            <a href="<?php echo e(route('password.request')); ?>">Esqueci-me da palavra-passe</a>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Desktop\LivrariaHub3-main\LivrariaHub3-main\LivrariaHub2-main\Livraria-Hub\resources\views/auth/login.blade.php ENDPATH**/ ?>