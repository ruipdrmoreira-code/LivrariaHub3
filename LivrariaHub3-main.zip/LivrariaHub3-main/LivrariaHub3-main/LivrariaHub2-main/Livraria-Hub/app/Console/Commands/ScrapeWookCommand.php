<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Symfony\Component\Process\Process;

class ScrapeWookCommand extends Command
{
    protected $signature = 'wook:scrape
                            {--backfill : Corrige preço/editora na BD (~10–15 min)}
                            {--full : Scrape completo com listagens}
                            {--reclassify : Recalcula tipo (manual/caderno) e disciplinas na BD (~1 min)}';

    protected $description = 'Atualiza livros Wook na base de dados (preço e editora).';

    public function handle(): int
    {
        $connection = config('database.default');
        $cfg = config("database.connections.{$connection}");

        if (($cfg['driver'] ?? '') !== 'mysql') {
            $this->error('A conexão ativa da base de dados tem de ser MySQL (DB_CONNECTION=mysql) para o scraper.');

            return self::FAILURE;
        }

        $scraperDir = base_path('scraper');
        $script = $scraperDir.DIRECTORY_SEPARATOR.'index.js';

        if (! is_file($script)) {
            $this->error("Ficheiro em falta: {$script}");

            return self::FAILURE;
        }

        $env = array_merge($_ENV, [
            'DB_HOST' => (string) ($cfg['host'] ?? '127.0.0.1'),
            'DB_PORT' => (string) ($cfg['port'] ?? 3306),
            'DB_USER' => (string) ($cfg['username'] ?? 'root'),
            'DB_USERNAME' => (string) ($cfg['username'] ?? 'root'),
            'DB_PASSWORD' => (string) ($cfg['password'] ?? ''),
            'DB_NAME' => (string) ($cfg['database'] ?? ''),
            'DB_DATABASE' => (string) ($cfg['database'] ?? ''),
        ]);

        $full = (bool) $this->option('full');
        $backfill = (bool) $this->option('backfill');
        $reclassify = (bool) $this->option('reclassify');

        if ($reclassify) {
            $env['SCRAPER_MODE'] = 'reclassify';
        } elseif ($full) {
            $env['SCRAPER_MODE'] = 'full';
        } elseif ($backfill) {
            $env['SCRAPER_MODE'] = 'backfill';
            $env['SCRAPER_ONLY_MISSING_DETAILS'] = 'true';
        } else {
            // Auto: backfill se houver dados; scrape completo se tabela vazia (após TRUNCATE)
            $env['SCRAPER_MODE'] = 'backfill';
            $env['SCRAPER_ONLY_MISSING_DETAILS'] = 'true';
        }

        $env['SCRAPER_FAST'] = $env['SCRAPER_FAST'] ?? 'true';
        if (empty($env['SCRAPER_CONCURRENCY'])) {
            $env['SCRAPER_CONCURRENCY'] = '12';
        }

        if ($reclassify) {
            $this->info('A reclassificar manuais/cadernos e disciplinas (~1 min)...');
        } else {
            $this->info('A correr scraper (~10-15 min). BD vazia = repopula; BD com dados = corrige preços/editoras.');
        }

        $process = new Process(['node', 'index.js'], $scraperDir, $env, null, null);
        $process->setTimeout(null);
        $process->run(function ($type, $buffer) {
            $this->output->write($buffer);
        });

        if (! $process->isSuccessful()) {
            $this->newLine();
            $this->error('O scraper terminou com erro.');

            return self::FAILURE;
        }

        $this->newLine();
        $this->info('Scraper concluído.');

        return self::SUCCESS;
    }
}
